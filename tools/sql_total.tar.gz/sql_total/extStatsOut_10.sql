insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 51);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 28);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 39);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 65);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 97);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 59);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 43);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 96);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 38);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 48);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 54);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 40);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 75);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 32);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 12);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 51);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 89);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 58);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 50);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 87);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 33);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 88);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 64);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 58);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 50);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 86);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 31);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 64);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 84);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 56);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 96);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 69);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 97);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 55);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 34);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 64);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 39);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 52);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 38);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 31);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 64);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 61);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 91);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 60);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 69);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 63);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 101);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 48);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 57);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 75);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 59);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 56);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 62);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 69);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 89);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 53);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 74);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 56);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 65);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 35);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 80);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 52);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 82);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 59);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 101);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 47);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 88);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 28);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 36);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 82);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 74);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 64);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 48);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 59);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 53);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 88);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 50);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 87);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 67);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 30);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 61);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 61);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 48);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 42);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 12);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 69);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 97);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Major_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 54);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 97);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 41);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 89);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 61);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 54);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 91);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 46);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 63);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 12);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 14);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 47);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 101);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 45);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 30);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 56);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 65);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 47);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 60);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 61);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 92);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 66);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 39);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 37);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 67);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 28);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 22);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 34);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 59);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 54);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 101);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 42);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 12);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 63);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 41);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 95);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 59);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 58);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 69);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 14);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 53);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 42);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 34);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 88);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 11);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 65);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 52);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 87);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 25);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 8);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 41);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 42);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 63);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 73);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 62);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 35);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 53);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 35);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 41);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 15);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 77);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 10);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 66);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 19);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 63);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 101);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 61);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 99);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 32);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 16);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 101);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 14);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 31);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 7);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 60);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 91);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 26);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 6);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 14);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 24);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 74);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 12);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 31);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 4);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 38);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 98);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 27);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 9);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 18);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 17);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 62);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 21);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 20);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 63);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 29);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 5);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 13);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 36);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 100);
commit;
insert into extended_stats (randoPreset, skillPreset, count)
values
('Season_Races_Full_total', 'Season_Races', 1)
on duplicate key update id=LAST_INSERT_ID(id), count = count + 1;
set @last_id = last_insert_id();
insert into solver_stats (ext_id, name, value) values (@last_id, 'avgLocs', 23);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open14', 3);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open24', 14);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open34', 54);
insert into solver_stats (ext_id, name, value) values (@last_id, 'open44', 102);
commit;
